package com.cg.SpringBootRestJpa.exception;

public class ProductException extends Exception {
	public ProductException() {
		
	}
	public ProductException(String msg) {
		super(msg);
	}

}
