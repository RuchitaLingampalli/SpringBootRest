package com.cg.SpringBootRestJpa.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBootRestJpa.Beans.Product;
import com.cg.SpringBootRestJpa.DAO.ProductDao;
import com.cg.SpringBootRestJpa.exception.ProductException;

@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductDao productDao;

	@Override
	public List<Product> addProduct(Product pro) throws ProductException {
		try {
	int amount=pro.getPrice()*pro.getQuantity();
    pro.setAmount(amount);
	
		productDao.save(pro);
		return productDao.findAll();
		}catch(Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public Product getProductById(long id) throws ProductException {
		try {
		return productDao.findById(id).get();
		}catch(Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public void deleteProduct(long id) throws ProductException {
		try {
		productDao.deleteById(id);
		}catch(Exception e) {
			throw new ProductException(e.getMessage());
		}
	
		
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		try {
		return productDao.findAll();
		}catch(Exception e) {
			throw new ProductException(e.getMessage());
		}
			}

	@Override
	public List<Product> updateProduct(long id, Product pro) throws ProductException{
		try {
		
		Optional<Product> optional=productDao.findById(id);
		if(optional.isPresent())
		{
			Product product=optional.get();
			product.setName(pro.getName());
			product.setModel(pro.getModel());
			product.setPrice(pro.getPrice());
			product.setQuantity(pro.getQuantity());
			
			int amount=pro.getPrice()*pro.getQuantity();
		    product.setAmount(amount);
			
			productDao.save(product);
			
		}
		return getAllProducts();
	}catch(Exception e) {
		throw new ProductException(e.getMessage());
	}
	}

}
